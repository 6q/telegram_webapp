window.ShippingTable = function(domElement) {

  this.init = function (domElement) {
    this.domElement = domElement;
    this.bindEvents();
  }

  this.bindEvents = function () {
    this.domElement.find('tfoot button').click(function (event) {
      event.preventDefault();
      this.addRow();
    }.bind(this));
  }

  this.renumberRows = function () {
    jQuery(this.domElement.find('tbody tr')).each(function (index, element) {
      element = jQuery(element);
      element.find('[data-role="label"]').attr('name', '_shipping_option['+index+'][label]');
      element.find('[data-role="price"]').attr('name', '_shipping_option['+index+'][price]');
      element.find('[data-role="additional_price"]').attr('name', '_shipping_option['+index+'][additional_price]');
    });
  }

  this.addRow = function () {
    var count = this.domElement.find('tbody tr').length;

    var row = jQuery('                                                                                                              \
      <tr>                                                                                                                          \
        <td><input type="text" data-role="label" name="_shipping_option['+count+'][label]"  value=""/></td>                         \
        <td><input type="text" data-role="price" name="_shipping_option['+count+'][price]" size="5" value=""/></td>                 \
        <td>                                                                                                                        \
          <input type="text" data-role="additional_price" name="_shipping_option['+count+'][additional_price]" size="5" value=""/>  \
        </td>                                                                                                                       \
        <td>                                                                                                                        \
          <button data-role="remove-shipping-option">x</button>                                                                     \
          <input type="hidden" name="_shipping_option['+count+'][id]" value=""/>                                                    \
        </td>                                                                                                                       \
      </tr>                                                                                                                         \
    ');

    row.find('button').click(function (event) {
      event.preventDefault();
      row.remove();
      this.renumberRows();
    }.bind(this));

    domElement.find('tbody').append(row);
    this.renumberRows();

    return row;
  }

  this.addRowWithData = function (data) {
    var row = this.addRow();

    var inputs = row.find('input');

    inputs.eq(0).val(data.label);
    inputs.eq(1).val(data.price);
    inputs.eq(2).val(data.additional_price);
    inputs.eq(3).val(data.id);
  }

  this.init(domElement);
}