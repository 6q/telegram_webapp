<?php
/*
Plugin Name: 1Thirteen - Shipping
Plugin URI: http://1thirteen.com/
Description: Let sellers take full control of their shipping options and prices. Per product, storewide, and more!
Version: 1.1.0
Author: 1Thirteen
Author URI: http://1thirteen.com/
License: GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}


if ( ! class_exists( 'OneThirteenShipping' ) ) :


  class OneThirteenShipping {
    private static $cart_calculator = null;


    protected static $_instance = null;
    public static function instance() {
      if ( is_null( self::$_instance ) ) {
        self::$_instance = new self();
      }
      return self::$_instance;
    }



    public static function get_cart_calculator () {
      if (!self::$cart_calculator) {
        self::$cart_calculator = new OneThirteenShippingWooCart(WC()->cart);
      }

      return self::$cart_calculator;
    }


    public function __construct() {
      require_once dirname(__FILE__) . '/includes/class-ot-license.php';

      require_once dirname(__FILE__) . '/includes/class-ot-shipping-base.php';
      require_once dirname(__FILE__) . '/includes/class-ot-shipping-woo-cart.php';
      require_once dirname(__FILE__) . '/includes/class-ot-shipping-woo-order.php';
      require_once dirname(__FILE__) . '/includes/class-ot-shipping-dokan-order.php';

      require_once dirname(__FILE__) . '/includes/class-ot-seller-tax.php';

      require_once dirname(__FILE__) . '/includes/class-ot-shipping-method.php';

      /****
      **  WOOCOMMERCE integratrion
      */
      // Return tax information
      add_filter('woocommerce_product_tax_class', array($this, 'tax_class'), 1, 2);
      add_filter('woocommerce_matched_rates', array($this, 'return_tax_class'), 1, 2);

      // Break a default package into multiple packages
      add_filter('woocommerce_cart_shipping_packages', array($this, 'shipping_packages_by_seller'), 1);

      // Add shipping via to each order item
      add_action('woocommerce_checkout_order_processed', array($this, 'add_meta_to_woo_order'), 1);


      // This will add the ship via column to the seller and admin views
      add_action('woocommerce_admin_order_item_headers', array($this, 'add_ship_header'));
      add_action('woocommerce_admin_order_item_values', array($this, 'add_ship_data'), 1, 3);


      /****
      **  DOKAN integratrion
      */
      // Add /ot-shipping endpoint
      add_filter('dokan_query_var_filter', array($this, 'add_query_vars'), 1);

      // Add store shipping nav tab
      add_filter('dokan_get_dashboard_nav', array($this, 'add_dokan_store_wide_shipping_tab'), 1);

      // Seller store wide shipping UI
      add_action('dokan_load_custom_template', array($this, 'load_store_shipping_template'));

      // Seller product shipping UI
      add_action('dokan_product_options_shipping', array($this, 'load_product_shipping_template'), 1);

      // Retrieve and set calculated shipping for order prior to saving
      add_action('dokan_checkout_update_order_meta', array($this, 'add_meta_to_dokan_order'), 1, 2);

      // Save product shipping
      add_action('dokan_process_product_meta', array($this, 'save_product_shipping_from_post'), 1);

      // Prevent dokan from executing the shipping calculation
      add_filter('dokan_shipping_method', array($this, 'prevent_dokan_from_adding_shipping'), 1);

      add_action('wp_loaded', array( $this, 'init' ), 99);
    }


    // Plugin init
    function init() {
      if ( is_admin() ) {
        new OneThirteenLicense();
      }

      wp_register_style('onethirteen-shipping', plugins_url('assets/css/shipping.css', __FILE__), false, null);
      wp_enqueue_style('onethirteen-shipping');
    }


    // If woocommerce_tax_based_on == 'base', then this will return
    // the highest tax rate based on the seller's address
    function tax_class ($tax_class, $product) {
      $tax_rate = OneThirteenSellerTax::tax_by_seller_for_product($product->post);
      if (array_key_exists('class', $tax_rate)) {
        return $tax_rate->class;
      }

      return $tax_class;
    }


    // Given a tax class, return the highest rate based
    // on the seller's address.
    //
    // Assumes that we have already cached this data.
    function return_tax_class ($matched_tax_rates, $tax_class) {
      $tax_rate = OneThirteenSellerTax::tax_rate_for_class($tax_class);
      if ($tax_rate) {
        return array($tax_rate);
      }

      return $matched_tax_rates;
    }


    // Overrides the default $packages array with packages
    // built based on seller shipping preferences.
    function shipping_packages_by_seller ($packages) {
      $original_package = $packages[0];
      $packages = array();

      $cart_calculator = self::get_cart_calculator();

      $cart_packages = $cart_calculator->get_packages();
      foreach ($cart_packages as $cart_package) {
        $package = $original_package;
        $package['contents'] = $cart_package->contents;
        $package['shipping_options'] = $cart_package->shipping_options;

        array_push($packages, $package);
      }

      return $packages;
    }


    // Add shipping information to the dokan order and ship via
    // metadata to each item
    function add_meta_to_dokan_order ($order_id, $seller_id){
      $dokan_order = new WC_Order($order_id);

      $existing_order_shipping = get_post_meta($order_id, '_order_shipping');

      $shipping_calculator = new OneThirteenShippingDokanOrder($dokan_order);
      $shipping_calculator->update_order_shipping_meta();
      $shipping_calculator->update_item_shipping_meta();
    }


    // Add ship via metadata to each item
    function add_meta_to_woo_order ($order_id) {
      $woo_order = new WC_Order($order_id);

      $existing_order_shipping = get_post_meta($order_id, '_order_shipping');

      $shipping_calculator = new OneThirteenShippingWooOrder($woo_order);
      $shipping_calculator->update_item_shipping_meta();
    }


    /****
      Add shipping options to product or store
    */
    public function add_shipping_options_to_product ($product_id, $shipping_options_json) {
      update_post_meta($product_id, '_shipping_options', $shipping_options_json);
    }

    public function add_shipping_options_to_store ($store_id, $shipping_options_json) {
      update_user_meta($store_id, '_shipping_options', $shipping_options_json);
    }

    /****
      Remove shipping options from product or store
    */
    public function remove_shipping_options_for_product ($product_id) {
      delete_post_meta($product_id, '_shipping_options');
    }

    public function remove_shipping_options_for_store ($store_id) {
      delete_user_meta($store_id, '_shipping_options');
    }


    /****
      Saving shipping metadata from post
    */
    function save_product_shipping_from_post () {
      $product_id = $_POST['dokan_product_id'];
      if (isset($_POST['_shipping_option']) && $_POST['which_shipping_method'] != 'store') {
        $shipping_options_json = self::convert_options_to_json($_POST['_shipping_option']);
        OTShipping()->add_shipping_options_to_product($product_id, $shipping_options_json);
      }
      else {
        OTShipping()->remove_shipping_options_for_product($product_id);
      }
    }

    function save_store_shipping_from_post () {
      $store_id = get_current_user_id();
      if (isset($_POST['_shipping_option'])) {
        $shipping_options_json = self::convert_options_to_json($_POST['_shipping_option']);
        OTShipping()->add_shipping_options_to_store($store_id, $shipping_options_json);
      }
      else {
        OTShipping()->remove_shipping_options_for_store($store_id);
      }
    }

    function convert_options_to_json ($shipping_options) {
      foreach ($shipping_options as $index => $shipping_option) {
        if (!array_key_exists('id', $shipping_option) || (array_key_exists('id', $shipping_option) && !$shipping_option['id'])) {
          $shipping_options[$index]['id'] = 'ot-'.uniqid();
        }
      }
      $shipping_options_json = json_encode($shipping_options);

      return $shipping_options_json;
    }


    /**************************************
    **  UI Code
    **************************************/
    // This will add the ship via column to the seller and admin views
    function add_ship_data ($product, $item, $item_id) {
      $meta = woocommerce_get_order_item_meta($item_id, '_shipping');
      echo "<td>$meta</td>";
    }

    function add_ship_header() {
      echo '<th>Ship</th>';
    }


    // Add store shipping nav tab
    function add_dokan_store_wide_shipping_tab ($urls) {
      unset($urls['shipping']);
      $urls += array('ot-shipping' =>
        array(
          'title' => __( 'Store Shipping', 'onethirteen-shipping'),
          'icon'  => '<i class="fa fa-truck"></i>',
          'url'   => dokan_get_navigation_url('ot-shipping')
        )
      );
      return $urls;
    }


    // Seller store wide shipping UI
    function load_store_shipping_template ($query_vars) {
      // Save the store shipping from the post
      if (isset($_POST['onethirteen-update-store-shipping'])) {
        OTShipping()->save_store_shipping_from_post();
      }

      if ( isset( $query_vars['ot-shipping'] ) ) {
        load_template(dirname(__FILE__).'/templates/template-store-shipping.php');

        wp_register_script('onethirteen-seller-shipping', plugins_url('assets/js/ShippingTable.js', __FILE__));
        wp_enqueue_script('onethirteen-seller-shipping');
      }
    }


    // Seller product shipping UI
    function load_product_shipping_template ($product_id) {
      load_template(dirname(__FILE__).'/templates/template-product-shipping.php');

      wp_register_script('onethirteen-seller-shipping', plugins_url('assets/js/ShippingTable.js', __FILE__));
      wp_enqueue_script('onethirteen-seller-shipping');
    }

    /****
      Dokan related functions
    */
    function add_query_vars ($query_vars) {
      $query_vars[] = 'ot-shipping';
      return $query_vars;
    }

    function prevent_dokan_from_adding_shipping () {
      return null;
    }
  }
endif;


function onethirteen_shipping_activate() {
  add_rewrite_endpoint('ot-shipping', EP_PAGES);
  flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'onethirteen_shipping_activate' );

function onethirteen_shipping_deactivate() {
  flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'onethirteen_shipping_deactivate' );



function OTShipping() {
  return OneThirteenShipping::instance();
}
OTShipping();