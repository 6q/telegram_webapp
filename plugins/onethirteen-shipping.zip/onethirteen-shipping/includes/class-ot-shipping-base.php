<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}


if ( ! class_exists( 'OneThirteenShippingBase' ) ) :
  class OneThirteenShippingBase {

    // product id : {post : {}, quantity : 22, tax-rate}
    protected $contents = array();

    // array of shipping method ids
    protected $chosen_shipping_methods = array();


    protected $packages = array();

    protected $seller_costs = array();

    public $total_shipping_cost = 0.00;
    public $total_shipping_tax = 0.00;

    private $shipping_options = array();

    protected static $store_shipping_options = array();
    protected static $product_shipping_options = array();

    protected $data = null;
    public function __construct ($cart_or_order) {
      $this->data = $cart_or_order;
      $this->init();
    }


    protected function init () {
      $this->break_contents_into_packages();
      $this->calculate_package_totals();
      $this->calculate_overall_totals();
    }


    protected function add_to_contents ($data) {
      $product_id = $data['product_id'];
      $variation_id = $data['variation_id'];
      $id_to_use = ($variation_id != 0 ? $variation_id : $product_id);
//       var_dump($data);
      if (!array_key_exists($id_to_use, $this->contents)) {

        // Get product post and tax rate
        $product_post = get_post($product_id);
        $tax_rate = OneThirteenSellerTax::tax_by_seller_for_product($product_id);


        // Quantity based on type of data that was passed
        $quantity = 0;
        if (array_key_exists('qty', $data)) {
          $quantity = $data['qty'];
        }
        else if (array_key_exists('quantity', $data)) {
          $quantity = $data['quantity'];
        }


        // Get shipping information
        $shipping_key = $this->get_shipping_options_key_for_product($product_post, $variation_id);

        // Construct the content object
        $this->contents[$id_to_use] = (object) array(
          "original_data" => $data,
          "product_post" => $product_post,
          "quantity" => $quantity,
          "seller_id" => $product_post->post_author,
          "shipping_key" => $shipping_key,
          "tax_rate" => $tax_rate
        );
      }
    }


    // Generate packages based on shipping keys
    private function break_contents_into_packages () {
      foreach ($this->contents as $content_object) {
        $package = $this->get_package_for_key($content_object->shipping_key);
        array_push($package->contents, $content_object->original_data);
        $package->quantity += $content_object->quantity;

        if (!$package->tax_rate) {
          $package->tax_rate = $content_object->tax_rate;
        }
        if (!$package->seller_id) {
          $package->seller_id = $content_object->seller_id;
        }
      }
    }



    public function get_packages () {
      return $this->packages;
    }


    public function calculate_overall_totals () {
      foreach ($this->packages as $package_key => $package) {
        $seller_id = $package->seller_id;
        if (!array_key_exists($seller_id, $this->seller_costs)) {
          $this->seller_costs[$seller_id] = (object) array(
            "shipping_cost" => 0.00,
            "shipping_tax" => 0.00
          );
        }

        $this->seller_costs[$seller_id]->shipping_cost += $package->shipping_cost;
        $this->seller_costs[$seller_id]->shipping_tax += $package->shipping_tax;

        $this->total_shipping_cost += $package->shipping_cost;
        $this->total_shipping_tax += $package->shipping_tax;
      }
    }

    /****
      Package methods
    */
    private function calculate_package_totals () {

      foreach ($this->packages as $package_key => $package) {
        $quantity = $package->quantity;

        $tax_rate = 0;
        if (array_key_exists('tax_rate', $package->tax_rate)) {
          $tax_rate = $package->tax_rate->rate;
        }
		if(count($package->shipping_options)){
	        foreach ($package->shipping_options as $shipping_option_key => $shipping_option) {
	
	          if (!array_key_exists('id', $shipping_option)) {
	            continue;
	          }
	
	          $cost = $shipping_option->price+(($quantity-1)*$shipping_option->additional_price);
	          $shipping_option->cost = $cost;
	          $shipping_option->tax = $cost*($tax_rate/100);
	
	          if (in_array($shipping_option->id, $this->chosen_shipping_methods)) {
	            $package->chosen_shipping_method = $shipping_option;
	            $package->shipping_cost = $shipping_option->cost;
	            $package->shipping_tax = $shipping_option->tax;
	          }
	
	        }
	    }
      }
    }

    private function get_package_for_key ($package_key) {
      if (!array_key_exists($package_key, $this->packages)) {
        $shipping_options = array();
        if (array_key_exists($package_key, $this->shipping_options)) {
          $shipping_options = $this->shipping_options[$package_key];
        }

        $package = (object) array(
          "chosen_shipping_method" => null,
          "contents" => array(),
          "quantity" => 0,
          "seller_id" => null,
          "shipping_cost" => 0,
          "shipping_options" => $shipping_options,
          "shipping_tax" => 0,
          "tax_rate" => (object) array()
        );
        $this->packages[$package_key] = $package;
      }

      return $this->packages[$package_key];
    }



    /****
      Shipping options, store statically to prevent continous lookups
    */
    // Return a md5 string representing the shipping options assigned
    // to this prooduct (seller or per product)
    private function get_shipping_options_key_for_product ($product_post, $variation_id) {
      $package_key = null;

      $product_id = $product_post->ID;
      $seller_id = $product_post->post_author;

      $shipping_options = OneThirteenShippingBase::get_shipping_options_for_product($product_id, $variation_id);
      if (!count($shipping_options)) {
        $shipping_options = $this->get_shipping_options_for_store($seller_id);
      }
//       $shipping_options = apply_filters('edibly_shipping_options', $shipping_options, $product_id, $variation_id, $seller_id);
	  
      $shipping_options_key = md5(json_encode($shipping_options));
      $this->add_shipping_options_for_key($shipping_options, $shipping_options_key);

      return $shipping_options_key;
    }


    // Stores this shipping options for later retrieval when calculating totals
    private function add_shipping_options_for_key ($shipping_options, $shipping_options_key) {
      $this->shipping_options[$shipping_options_key] = $shipping_options;
    }


    // Return shipping options defined for this product
    public static function get_shipping_options_for_product ($product_id, $variation_id) {
      $id_to_use = ($variation_id != 0 ? $variation_id : $product_id);
      if (!array_key_exists($id_to_use, self::$product_shipping_options)) {
//         $shipping_json = get_post_meta($id_to_use, '_shipping_options', true);
        self::$product_shipping_options[$id_to_use] = array();
        self::$product_shipping_options[$id_to_use] = apply_filters('ot_shipping_options_for_product', self::$product_shipping_options[$id_to_use], $product_id, $variation_id);
      }

      return self::$product_shipping_options[$id_to_use];
    }


    // Return shipping options defined for this store
    public static function get_shipping_options_for_store ($store_id) {
      if (!array_key_exists($store_id, self::$store_shipping_options)) {
        $store = get_userdata($store_id);
        $shipping_json = get_user_meta($store_id, '_shipping_options', true);
        $shipping_options = json_decode($shipping_json);

        self::$store_shipping_options[$store_id] = $shipping_options;
      }

      return self::$store_shipping_options[$store_id];
    }


    public function get_seller_costs () {
      return $this->seller_costs;
    }

    public function get_shipping_for_product ($product_id, $variation_id) {
      $label = '';
      $id_to_use = ($variation_id != 0 ? $variation_id : $product_id);
      if (array_key_exists($id_to_use, $this->contents)) {
        $content_object = $this->contents[$id_to_use];
        $package = $this->get_package_for_key($content_object->shipping_key);

        if ($package->chosen_shipping_method) {
          return $package->chosen_shipping_method;
        }
      }

      return $label;
    }
  }

endif;



?>