<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}


if ( ! class_exists( 'OneThirteenShippingWooOrder' ) ) :
  class OneThirteenShippingWooOrder extends OneThirteenShippingBase {
    protected function init () {
      $order = $this->data;

      // Get all items and process
      $items = $order->get_items();
      foreach ($items as $item_key => $item) {
        $content_object = $this->add_to_contents($item);
      }

      $shipping_methods = $order->get_items('shipping');
      foreach ($shipping_methods as $item_key => $shipping_metod) {
        array_push($this->chosen_shipping_methods, $shipping_metod['method_id']);
      }

      parent::init();
    }


    public function update_item_shipping_meta () {
      $order = $this->data;

      $order_id = $order->id;
      $items = $order->get_items();
      foreach ($items as $item_key => $item) {
        $shipping = $this->get_shipping_for_product($item['product_id'], $item['variation_id']);
        wc_update_order_item_meta($item_key, '_shipping', $shipping->label);
      }
    }
  }
endif;
