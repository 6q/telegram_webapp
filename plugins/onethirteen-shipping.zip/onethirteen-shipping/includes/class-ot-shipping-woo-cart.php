<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}


if ( ! class_exists( 'OneThirteenShippingWooCart' ) ) :
  class OneThirteenShippingWooCart extends OneThirteenShippingBase {
    protected function init () {
      $cart = $this->data;

      // Get all items and process
      $items = $cart->cart_contents;
      foreach ($items as $item_key => $item) {
        $content_object = $this->add_to_contents($item);
      }


      $chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
      if ($chosen_shipping_methods) {
        foreach ($chosen_shipping_methods as $shipping_metod_id) {
          array_push($this->chosen_shipping_methods, $shipping_metod_id);
        }
      }

      parent::init();
    }
  }
endif;
