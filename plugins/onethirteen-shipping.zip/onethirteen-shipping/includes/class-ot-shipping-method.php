<?php

/**
 * Check if WooCommerce is active
 */
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

  function OneThirteen_Shipping_init() {
    if ( ! class_exists( 'OneThirteen_Shipping' ) ) {
      class OneThirteen_Shipping extends WC_Shipping_Method {
        /**
         * Constructor for your shipping class
         *
         * @access public
         * @return void
         */
        public function __construct() {
          $this->id = 'OneThirteen_Shipping';
          $this->method_title = __( 'OneThirteen Shipping' );
          $this->method_description = __( 'Enable sellers to set shipping cost storewide or per product.' );
          $this->title = "OneThirteen Shipping";

          $this->enabled = $this->get_option('enabled');

          $this->init();
        }

        function init_form_fields() {

          $this->form_fields = array(
            'enabled' => array(
              'title'         => 'Enable/Disable',
              'type'          => 'checkbox',
              'label'         => 'Enable this shipping method',
              'default'       => 'yes'
            )
          );
        }

        /**
         * Init your settings
         *
         * @access public
         * @return void
         */
        function init() {
          // Load the settings API
          $this->init_form_fields();
          $this->init_settings();

          // Save settings in admin if you have any defined
          add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
        }

        public function calculate_shipping( $package ) {
	      if(count($package['shipping_options'])){
	          foreach ($package['shipping_options'] as $shipping_option) {
	            $this->add_rate(array(
	              'id' => $shipping_option->id,
	              'label' => $shipping_option->label,
	              'cost' => $shipping_option->cost,
	              'calc_tax' => 'per_order',
	              'taxes' => array($shipping_option->tax)
	            ));
	          }
          }
        }
      }
    }
  }

  add_action( 'woocommerce_shipping_init', 'OneThirteen_Shipping_init' );

  function add_one_thirteen_shipping( $methods ) {
    $methods[] = 'OneThirteen_Shipping';
    return $methods;
  }

  add_filter( 'woocommerce_shipping_methods', 'add_one_thirteen_shipping' );
}
