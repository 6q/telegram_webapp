<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}


if ( ! class_exists( 'OneThirteenSellerTax' ) ) :
  class OneThirteenSellerTax {
    private static $seller_tax_cache = array();
    private static $cust_tax_cache = array();
    private static $product_tax_cache = array();
    private static $tax_class_cache = array();

    // If woocommerce_tax_based_on == 'base', return the highest tax rate
    // represented by the seller's address
    public static function tax_by_seller_for_product ($product_post) {
      $tax_based_on = get_option('woocommerce_tax_based_on');

      if ($tax_based_on == 'base') {
        $seller_id = $product_post->post_author;

        if (!array_key_exists($seller_id, self::$seller_tax_cache)) {
          $seller_address  = wc_get_base_location();

          $seller_address['country'] = get_user_meta($seller_id, 'billing_country', true);
          $seller_address['state'] = get_user_meta($seller_id, 'billing_state', true);
          $seller_address['city'] = get_user_meta($seller_id, 'billing_city', true);
          $seller_address['postcode'] = get_user_meta($seller_id, 'billing_postcode', true);

          $tax_rates = WC_Tax::find_rates($seller_address);
          $highest_rate = self::get_highest_tax_rate($tax_rates);
          self::$seller_tax_cache[$seller_id] = $highest_rate;
        }

        return self::$seller_tax_cache[$seller_id];
      }
      
      if ($tax_based_on == 'shipping') {
        $cust_id = get_current_user_id();

        if (!array_key_exists($cust_id, self::$cust_tax_cache)) {
          $cust_address  = wc_get_base_location();

          $cust_address['country'] = get_user_meta($cust_id, 'shipping_country', true);
          $cust_address['state'] = get_user_meta($cust_id, 'shipping_state', true);
          $cust_address['city'] = get_user_meta($cust_id, 'shipping_city', true);
          $cust_address['postcode'] = get_user_meta($cust_id, 'shipping_postcode', true);

          $tax_rates = WC_Tax::find_rates($cust_address);
          $highest_rate = self::get_highest_tax_rate($tax_rates);
          self::$cust_tax_cache[$cust_id] = $highest_rate;
        }

        return self::$cust_tax_cache[$cust_id];
      }
      
      return null;
    }

    // Based on the given array of tax rates,
    // return the one that represents the highest rate
    private static function get_highest_tax_rate ($tax_rates) {
      $highest_rate = null;
      $rate = 0.00;
      foreach ($tax_rates as $tax_rate_id => $tax_rate) {
        if ($tax_rate['rate'] > $rate) {
          $rate = $tax_rate['rate'];
          $highest_rate = $tax_rate;
          $highest_rate['id'] = $tax_rate_id;
          $highest_rate['class'] = sanitize_title($highest_rate['label']);
        }
      }

      self::$tax_class_cache[$highest_rate['class']] = $highest_rate;

      return (object) $highest_rate;
    }


    // Get the rate array for a given class
    // If this hasn't been cached previously, null is returned
    public static function tax_rate_for_class ($tax_class) {
      if (array_key_exists($tax_class, self::$tax_class_cache)) {
        return self::$tax_class_cache[$tax_class];
      }

      return null;
    }
  }
endif;


