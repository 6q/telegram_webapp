<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}


if ( ! class_exists( 'OneThirteenLicense' ) ) :
  define('SECRET_KEY', '54cd8706efb6e0.06739178'); //Rename this constant name so it is specific to your plugin or theme.
  define('LICENSE_SERVER_URL', 'http://1thirteen.com'); //Rename this constant name so it is specific to your plugin or theme.
  define('ITEM_REFERENCE', 'My First Plugin'); //Rename this constant name so it is specific to your plugin or theme.

  class OneThirteenLicense {

    public static function get_license_key() {
      return get_option('1thirteen-shipping-license', array() );
    }


    public function __construct () {
      add_filter('plugin_action_links_'.plugin_basename(__FILE__), array($this, 'add_action_links'));
      add_action('admin_menu', array($this, 'add_admin_menu'));
    }


    // Settings page
    public function add_action_links( $links ) {
      $settings_link = '<a href="admin.php?page='.basename( __FILE__ ).'">Settings</a>';
      array_unshift( $links, $settings_link );
      return $links;
    }

    public function add_admin_menu () {
      add_management_page("1Thirteen Shipping", "1Thirteen Shipping", apply_filters('1thirteen_role', 'administrator'), basename( __FILE__ ), array( &$this, "admin_screen" ));
    }


    public function admin_screen () {
      if (array_key_exists('license_key', $_POST)) {
        $this->activate_license($_POST['license_key']);
      }
      elseif (array_key_exists('deactivate', $_POST)) {
        $this->deactivate_license();
      }

      $this->enter_license_notice();

      load_template(dirname(__FILE__).'/../templates/template-admin-settings.php');
    }

    private function activate_license ($license_key) {
      $api_params = array(
        'slm_action' => 'slm_activate',
        'secret_key' => SECRET_KEY,
        'license_key' => $license_key,
        'registered_domain' => $_SERVER['SERVER_NAME'],
        'item_reference' => urlencode(ITEM_REFERENCE),
      );

      // Send query to the license manager server
      $response = wp_remote_get(add_query_arg($api_params, LICENSE_SERVER_URL), array('timeout' => 20, 'sslverify' => false));

      // Check for error in the response
      if (is_wp_error($response)){
          $this->render_error("Unexpected Error! The query returned with an error.");
      }

      // License data.
      $license_data = json_decode(wp_remote_retrieve_body($response));

      if($license_data->result == 'success'){
        update_option('1thirteen-shipping-license', $license_key);
        $this->render_message('1Thirteen shipping registered');
      }
      else{
        $this->render_error($license_data->message);
      }
    }

    private function deactivate_license () {
      $api_params = array(
        'slm_action' => 'slm_deactivate',
        'secret_key' => SECRET_KEY,
        'license_key' => self::get_license_key(),
        'registered_domain' => $_SERVER['SERVER_NAME'],
        'item_reference' => urlencode(ITEM_REFERENCE),
      );

      // Send query to the license manager server
      $response = wp_remote_get(add_query_arg($api_params, LICENSE_SERVER_URL), array('timeout' => 20, 'sslverify' => false));

      // Check for error in the response
      if (is_wp_error($response)){
        $this->render_error("Unexpected Error! The query returned with an error.");
      }

      // License data.
      $license_data = json_decode(wp_remote_retrieve_body($response));

      if($license_data->result == 'success'){
        delete_option('1thirteen-shipping-license');
        $this->render_message('1Thirteen shipping deactivated');
      }
      else{
        $this->render_error($license_data->message);
      }
    }

    private function render_error( $message ) {
    ?>
  <div class="fade error" id="message">
    <p><b>1Thirteen Shipping:</b> <?php echo $message ?></p>
  </div>
  <?php
    }

    private function render_message( $message, $timeout = 0 ) {
      ?>
  <div class="updated" id="message" onclick="this.parentNode.removeChild(this)">
    <p><b>1Thirteen Shipping:</b> <?php echo $message ?></p>
  </div>
    <?php
    }


    function enter_license_notice () {
      if ($key = $this->get_license_key()) {
        return;
      }
      ?>
        <div class="error">
        <p><?php printf( __( 'Please <a href="%s">enter</a> your <strong>1Thirteen Shipping</strong> plugin license key to get regular update and support.', 'onethirteen' ), admin_url( 'admin.php?page='.basename( __FILE__ ) ) ); ?></p>
        </div>
      <?php
    }
  }
endif;
