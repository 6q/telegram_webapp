<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}


if ( ! class_exists( 'OneThirteenShippingDokanOrder' ) ) :
  class OneThirteenShippingDokanOrder extends OneThirteenShippingWooOrder {
    protected function init () {
      $order = $this->data;

      // Get all items and process
      $items = $order->get_items();
      foreach ($items as $item_key => $item) {
        $content_object = $this->add_to_contents($item);
      }

      // Gather selected shipping options
      $parent_order_id = $order->post->post_parent;
      $parent_order = new WC_Order($parent_order_id);
      $shipping_methods = $parent_order->get_items('shipping');
      foreach ($shipping_methods as $item_key => $shipping_metod) {
        array_push($this->chosen_shipping_methods, $shipping_metod['method_id']);
      }

      parent::init();
    }

    public function update_order_shipping_meta () {
      $order = $this->data;

      $packages = $this->get_packages();
      foreach ($packages as $package) {
        if ($package->chosen_shipping_method) {
          $chosen_method = $package->chosen_shipping_method;
          $chosen_method->taxes = array($chosen_method->tax);
          if (!$order->has_shipping_method($chosen_method->id)) {
            $order->add_shipping($chosen_method);
          }
        }
      }

      $order->set_total($this->total_shipping_tax, 'shipping_tax');
      $order->calculate_totals(false);
    }
  }
endif;
