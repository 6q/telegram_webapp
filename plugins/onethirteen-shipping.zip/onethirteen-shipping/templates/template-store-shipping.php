<?php
  $store_id = get_current_user_id();
  $shipping_options = OneThirteenShippingBase::get_shipping_options_for_store($store_id);
?>


<div class="dokan-dashboard-wrap">
  <?php

        /**
         *  dokan_dashboard_content_before hook
         *
         *  @hooked get_dashboard_side_navigation
         *
         *  @since 2.4
         */
        do_action( 'dokan_dashboard_content_before' );
    ?>

  <div class="dokan-dashboard-content">
    <p>
      These shipping preferences will be the default shipping costs for EVERY PRODUCT added to your vendor storefront.<br/>
      If there are any products that you do not wish to adhere to these shipping preferences, enter product specific details in the "Shipping" tab for the product.
    </p>

    <form method="post" id="onethirteen-shipping-form" action="">
      <?php require_once(__DIR__.'/template-seller-shipping.php'); ?>
      <input type="submit" name="onethirteen-update-store-shipping" class="btn btn-primary" value="Update Store Shipping">
    </form>
  </div>
</div>