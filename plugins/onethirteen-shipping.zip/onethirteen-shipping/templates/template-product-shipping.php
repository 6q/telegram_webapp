<?php
  $product_id = $post->ID;
  $shipping_options = OneThirteenShippingBase::get_shipping_options_for_product($product_id, null);
  $using_store_shipping = count($shipping_options);
?>
<div id="onethirteen-product-shipping-selectors">
<input type="radio" name="which_shipping_method" value="store" <?php if (!$using_store_shipping) { echo 'checked="checked"';} ?>/> Default Storewide Shipping<br/>
<input type="radio" name="which_shipping_method" value="product" <?php if ($using_store_shipping) { echo 'checked="checked"';}?>/> Product Specific Shipping<br/>
</div>
<?php require_once(__DIR__.'/template-seller-shipping.php'); ?>


<script>
  var checkShippingMethod = function () {
    var element = jQuery('[name="which_shipping_method"]:checked');
    if (element.val() == 'store') {
      jQuery('#onethirteen-shipping').hide();
    }
    else {
      jQuery('#onethirteen-shipping').show();
    }
  }

  jQuery('body').ready(function () {
    jQuery('[name="which_shipping_method"]').click(function () {
      checkShippingMethod();
    });

    checkShippingMethod();
  });
</script>