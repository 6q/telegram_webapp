
<div class="wrap">
  <?php screen_icon( ); ?>

  <h2>1Thirteen Shipping Options</h2>

  <?php
    $license_key = OneThirteenLicense::get_license_key();
    if (!$license_key):
  ?>


  <form method="post" action="">
    <table cellpadding="3" width="100%" class="form-table">
      <tr>
        <th align="right">License key</th>
        <td>
          <input type="text" name="license_key"/>
        </td>
      </tr>
    </table>
    <input class="button-primary" type="submit" name="update" value="Activate License"/>
  </form>

  <?php
    else :
  ?>

  <form method="post" action="">
    1Thirteen shipping is registered.
    <input type="hidden" name="deactivate" value="deactivate"/>
    <input class="button-primary" type="submit" name="update" value="Unregister License"/>
  </form>

  <?php
    endif;
  ?>
</div>