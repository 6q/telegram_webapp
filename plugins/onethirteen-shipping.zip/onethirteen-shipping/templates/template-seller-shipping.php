<div id="onethirteen-shipping">
  <table id="seller-shipping-options">
    <thead>
      <tr>
        <th>Shipping Label</th>
        <th>Shipping Price</th>
        <th>Additional Qty Price</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    </tbody>
    <tfoot>
      <tr>
        <td colspan="4">
          <button>Add Shipping Option</button>
        </td>
      </tr>
    </tfoot>
  </table>



  <script>
    jQuery('body').ready(function () {
      var shipping = new ShippingTable(jQuery('#seller-shipping-options'));

      <?php
        if (count($shipping_options)) {
          foreach ($shipping_options as $shipping_option) {
      ?>
          shipping.addRowWithData(<?php echo json_encode($shipping_option) ?>);
      <?php
          }
        }
      ?>
    });
  </script>
</div>
