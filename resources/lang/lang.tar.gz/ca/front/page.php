<?php

return [
	'bot_user' => 'Bot User',
	'created' => 'Created',
	'text' => 'Text',
	'no_record' => 'No Message Found',
	'message' => 'Message',
	'summary' => 'Summary',
	'add_new_bot_chanel' => 'Add a new Bot & Channel',
	'detail' => 'Page Detail'
];