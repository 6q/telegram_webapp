<?php

return [
	'bot_user' => 'Usuari',
	'created' => 'Data',
	'text' => 'Entrada de l\'usuari',
	'no_record' => 'No hi ha activitats',
	'message' => 'Activitats recents dels usuaris amb els bots',
	'summary' => 'Resum',
	'reply' => 'Resposta del bot',
];