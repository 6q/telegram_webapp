<?php

return [
	'dashboard' => 'Comments gestion',
	'comments' => 'Comments',
	'author' => 'Author',		
	'date' => 'Date',
	'post' => 'Post',
	'valid' => 'valid',
	'seen' => 'seen',
	'destroy' => 'Destroy',
	'destroy-warning' => 'Really destroy this comment ?',
	'fail' => 'Update fail.'	
];