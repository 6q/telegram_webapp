<?php
return [
	'administration' => 'Administration',
	'redaction' => 'Redaction',
	'home' => 'Back on site',
	'logout' => 'Logout',
	'dashboard' => 'Dashboard',
	'users' => 'Users',
	'plans' => 'Plans',
	'see-all' => 'View all',
	'add' => 'Add',
	'messages' => 'Channels',
	'comments' => 'Comments',
	'medias' => 'Medias',
	'posts' => 'Bots',
	'new-messages' => 'Total channels !',
	'new-registers' => 'New users !',
	'new-posts' => 'Total bots !',
	'new-comments' => 'New comments !',
	'page' => 'Pages',
	'emailtemplate' => 'E-mail template',
	'setting' => 'Site Setting'
];
