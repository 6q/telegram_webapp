<?php

return [
	'dashboard' => 'User Billings',
	'address' => 'Address',
	'country_id' => 'Country',
	'state_id' => 'State',
	'city' => 'City',
	'zipcode' => 'Zipcode'	
	
];