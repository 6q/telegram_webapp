<?php

return [
	'dashboard' => 'User Transactions',
	'plan' => 'Plan',
	'price' => 'Price',
	'type' => 'Type',
	'date' => 'Date'
	
];