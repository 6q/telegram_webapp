<?php

return [
	'dashboard' => 'User Subscriptions',
	'plan' => 'Plan',
	'price' => 'Price',
	'type' => 'Type',
	'subscription_date' => 'Subscription Date',
	'expiry_date' => 'Expiry Date'	
	
];