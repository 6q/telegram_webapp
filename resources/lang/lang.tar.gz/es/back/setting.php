<?php

return [
	'dashboard' => 'User Billings',
	'view_site_setting' => 'View Site Setting & update',
	'created' => 'Setting update successfully'
];