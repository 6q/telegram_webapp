<?php
return [
	'name' => 'Name',
	'created_at' => 'Created at',
	'actions' => 'Actions',
	'mychannel_detail' => 'Channel detail',
	'stripe_customer_id' => 'Stripe customer id',
	'no_record' => 'No Record found',
	'messages' => 'Send Messages',
	'users' => 'Channels',
	'dashboard' => 'Channels',
	'back' => 'Back'
];