<?php

return [
	'connection' => 'Login Account',
	'login_text' => 'Login',
	'send' => 'Login',
	'login_desc' => 'Lorem Ipsum proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc. Etiam pharetra, erat sed fermentum feugiat, velit mauris egest',
	'text' => 'Enter Email & Password to log in',
	'email' => 'Your email',
	'password' => 'Password',
	'remind' => 'Remember me',
	'forget' => 'Forget password',
	'register' => 'Not registered ?',
	'register-info' => 'To register quickly just click on the button !',
	'registering' => 'Click here to Register',
	'credentials' => 'These credentials do not match our records.',
	'log' => 'Email',
	'maxattempt' => 'You have reached the maximum number of login attempts. Try again in one minute.'
];