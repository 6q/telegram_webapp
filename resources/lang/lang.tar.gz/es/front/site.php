<?php

return [
	'title' => 'Citymes',
	'sub-title' => 'Instant Messaging Management Platform',
	'home' => 'Home',
	'contact' => 'Contact',
	'dashboard' => 'Dashboard',
	'register' => 'Register',
	'forget-password' => 'Forgotten password',
	'connection' => 'Connection',
	'administration' => 'Administration',
	'redaction' => 'Redaction',
	'logout' => 'Logout'
];
